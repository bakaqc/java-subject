package ex07_QE170097;

abstract class Shape {

    public static final double PI = 3.14159265359;
    public abstract double Perimeter();
    public abstract double Area();
}
