package ex08_QE170097;

public abstract class Number {

    public Number() {
    }

    public abstract void add(Number n);

    public abstract void subtract(Number n);

    public abstract void multiply(Number n);

    public abstract void divide(Number n);
}